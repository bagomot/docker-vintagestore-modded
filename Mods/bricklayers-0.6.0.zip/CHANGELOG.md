
# v0.6.0 - 2021-11-12 - Porcelain

## Bugfixes

* #246 - Fix German Translation errors (quartz etc.)
* #245 - Fix lapis powdering (again!)
* #244 - Fix errors due to 1.15.8 updates (chimney-fire patch)
* #243 - Update Russian and Spanish translations
* #241 - Slabs of non-plain colored glass could only be oriented 'auto'
* #237 - Tweaked trader prices, reduced amount of items added to vanilla traders

## Balancing and Tweaking

* #249 - Plant based dyes now need to be sealed in the barrel for some time

## New features

* #248 - Add usages for chromite: pigment, refractory bricks, coloring for dyes, glazes and glass
* #240 - Added two new traders: pottery and glass
* #239 - Added biscuit and glazed bone porcelain crafting + porcelain items
* #238 - Refractory bricks stack better, fire up to 16 (was: 12) in a kiln

# v0.5.2 - 2021-10-22 - Roof And Tile Fixes

## Bugfixes

* #235 - Clay shingle roofs had the wrong shape
* #232 - Tiles placed as decoration are now thinner

# v0.5.1 - 2021-10-21 - Shingle Colors

## Bugfixes

* #233 - Fix attached tile translations
* #228 - Add missing shingle clay-forming recipes (Thanx Xelephant and TheWigglesGaming!)
* #226 - Fix spanish translation not showing (Thanx Darce!)

## New features

* #227 - Add white opaque glass (glass batch and blocks/slabs)

# v0.5.0 - 2021-10-15 - Shingles all the way

## Bugfixes

* #221 - Add missing obsidian stone brick recipes
* #216 - remap glass batch codes to fix broken items

## New features

* #219 - Add Spanish translation by Darce
* #218 - Add Russian translation by Craluminum
* #207 - Craft more colored clay shingles and roof pieces
* #66 - Traders now sell & buy some of the new items and blocks

# v0.4.1 - 2021-09-28 - Sealing it up

## Bugfixes

* #214 - Colored crocks could not be sealed
* #211 - Correct language entries (spellings, double entries)
* #209 - Fix some glass batch descriptions

## New features

* #212 - Allow recycling of thatch, copper and slate roofing pieces
* #210 - Allow sawing cobblestone blocks into slabs
* #203 - Add suevite small stone bricks

# v0.4.0 - 2021-09-18 - The Tiles Release

## Bugfixes

* #191 - Make holding of powdered stuff "twohanded"
* #181 - Pit kiln layout for colored vessels now matches vanilla vessels
* #92  - Enable glass chiseling for all colors and types

## New features

* #201 - Add crushed titanium and conversion of powdered titanium => powdered ilmenite
* #198 - Add colored glass slabs for all glass colors and types (milky, smoky etc.)
* #192 - Add stone tiles: used for decoration and for cheaper "polished rock" blocks
* #191 - Add bone ash for milky glazings, milky, quartz and smoky glass and as fertilizer
* #189 - Add crushing of metal bits for: gold, copper, tin and lead
* #188 - Add crushed tin and conversion of powdered tin => powdered cassiterite
* #186 - Add colored watercans formed from colored clay
* #184 - Add colored crocks formed from colored clay
* #182 - Add colored tool and anvil molds formed from colored clay
* #180 - Allow forming of red and brown clay shingles from colored clay
* #144 - Add new glass color: black glass
* #137 - Add glass types: milky, dark and opaque. Make all colors available in all types
* #104 - Add 4 more clay colors: black, dark-grey, blue, purple

## Balancing and Tweaking

* #179 - Clear glazings now have a bit of a "shine" like polished rocks
* #104 - "Blue clay" is now known as "Blue-grey" clay and has a more distinct look

# v0.3.4 - 2021-08-15 - Fixes and tweaks

## Bugfixes

* #177 - Red and brown clay bricks could not be fired in a kiln (Reported by TechRabbit)
* #172 - Brown clay needs now green clay as input
* #169 - For 1.15.3: Remove halite from drystone wall recycling recipes

## New features

* #127 - Stack up to 32 (was: 24) raw clay or clazed bricks per block
* #127 - Fire up to 16 (was: 12) raw clay or clazed bricks in a pit kiln

# v0.3.3 - 2021-08-02 - More Fixes

## Bugfixes

* #170 - Cannot fire raw glazed planters in pit kilns

# v0.3.2 - 2021-07-31 - Fixes for 1.15.3

## Bugfixes

* #166 - For 1.15.3: fix lapis, cinnabar and lead crushing

## New Features

* #165 - Add kimberlite stone and small stone bricks
* #160 - glazed bowls can be used for oil lamps
* #156 - add bamboo stack and roof piece recycling

# v0.3.1 - 2021-07-26 - Tweaks to the Clayed Release

## Bugfixes

* #161 - glazed bowls with meals held wrongly in TP (Reported by Cirdanoth)
* #159 - Tweak nugget crushing (add hematite, limonite, magnetite and pentlandite)
* #159 - Tweak ingot crushing: double the output of copper, gold and lead
* #158 - "Lapis lazuli" had no space in the name (Reported by Cirdanoth)
* #157 - Remove broken `game:lang/` patches (Reported by Lisabet)
* #154 - Cannot use glazed bowls with honey in recipes
* #153 - Reduce handbook clutter by grouping items (Reported by Craluminum)

## Balancing and Tweaking

* #163 - allow use of olivine for green clay

# v0.3.0 - 2021-07-16 - The Clayed Release

## Compatibility

The mod is now compatible with VS v1.15:

* Ceramics, pottery and patterns can now be placed on the ground
* Ceramics, pottery, patterns and glazed bricks must now be fired in a kiln
* You can stack raw or burnt glazed bricks on the ground
* Added some dye recipes based on metals
* Use `recipeGroup` to sep. building from recycling/transformation recipes
* Add recycling recipes for drystone blocks and fences

## New Features

* Craft flowerpots, planters and storage vessels from colored clay
* Single glazed bricks can now be put on a shelf or in a display case
* Recycle glazed brick and small stone brick blocks, stairs and slabs
* Recycle glass by smashing it with a hammer or pickaxe
* Added recipe for lead-based ruby gold glass (gold + tin + lead oxide)
* Added pentlandite crushing and powdered nickel
* Added crushed and powdered iron variants (limonite, magnetite, hematite)
* Slabs from small stonebricks and hardened clay can now be oriented horizontally/vertically

## Bugfixes

* Include missing files like LICENSE and README in the release archive
* Set correct stack sizes for colored and glazed planters, flowerpots and vessels

## Balancing and Tweaking

* Metal crushing recipes changed to match v1.15 outputs
* Disabled nugget crushing for metals that have non-compatible amounts in v1.15
* All glass colors are now based on metal ions and oxides
* `Red` components in glass recipes can always take any of the red color ingredients
* Allow crushing copper, gold and lead ingots to make up for lost nugget crushing

# v0.2.1 - 2021-06-10 - Tweaks for Glass

## Balancing and Tweaking

* Glass batches need 60% less ingredients, and 1/2 the burn time & fuel
* Allow converting Litharge back to Massicot
* Set the real galena => lead oxide conversion temperature (1000°)
* Optimized glazed planter & flowerpot: use 9 vs. 21 cubes & overlay textures instead of extra faces

## Bugfixes

* Add the missing "hardened clay slabs" => "blocks" recipe
* Fix recycling recipe for glazed bricks
* Fix recipe for combining clayshingle slabs into blocks

## Compatibility

* Glazed planters are now compatible with CarryCapacity

# v0.2.0 - 2021-06-03 - Glazing and Glassmaking

This version adds a new late-game mechanic for
creating glazes and colored glass, complete
with a detailed guide in the handbook.

## New features

* Create 15 different glass colors (called "frit")
* Create milky or clear glazes in 15 colors each
* Glaze bricks, bowls, flowerpots and planters
* Create and apply patterns to glazed flowerpots or planters
* Mix and smelt colored glass (in the existing VS colors)
* Build blocks, slabs and stairs from glazed bricks
* Saw hardened clay blocks in half to create slabs
* Create colored clay and bake it into hardened clay blocks

# v0.1.2 - 2021-05-13 - Add Missing Obsidian recipes

## Fixes

* Add missing recipe variants for obsidian small stone bricks, slabs and stairs (Thanx Lisabet!)

# v0.1.1 - 2021-05-12 - Obsidian tweaks

## Fixes

* Fix warning about removing `/textures` in polishedrockslab.json
* Add the omitted recipe for polishing slabs into obsidian stonebricks
* Tweak obsidian brick textures to be darker than the base rock

# v0.1.0 - 2021-05-11 - Small stone bricks

## New features

* Polish stonebricks into small stone bricks
* Craft stonebrick blocks, slabs and stairs with smaller bricks
* Polish obsidian into blocks and slabs

# v0.0.3 - 2021-05-03 - Shingle recipes

## Additional recipes

* Saw shingle blocks into slabs
* Combine two shingle slabs into full shingle blocks
* Combine three shingle slabs into shingle stairs
* Use a hammer or pickaxe to break down shingle blocks, slabs or stairs into shingles

# v0.0.2 - 2021-04-25 - Recipe fixes

## Fixes

* The recipe for transforming stone blocks or stairs into slabs have
the shovel now on the side (no longer on top) to be consistent
with all other "transforming" recipes that use a saw.

# v0.0.1 - 2021-03-21 - First Bricks Thrown

## New Features

### Block transformations

* Saw cobble, stonebrick and claybrick blocks into slabs
* Combine cobble slabs with clay into full cobble blocks
* Combine two clay or stone brick slabs with mortar into full brick blocks
* Combine two stonepath slabs into stonepath blocks
* Combine three stonepath slabs into stonepath stairs
* You can craft chimneys also with mortar (to be consistent with other brick blocks)
* You can craft brick stairs consistent to cobble stairs (edge on the top-left corner)

### Recycling

* Use a hammer or pickaxe to break down cobble blocks or slabs into rocks
* Use a saw to saw clay or stone brick blocks, slabs, stairs or chimneys back into bricks
* Use a shovel to break stonepath blocks or stairs back into stonepath slabs

#### Note:

The vanilla clay brick blocks, slabs, stairs and chimneys have yields inconsistent with f.i. cobble stairs.
In addition, brick slabs need 5 bricks, compared to cobble slabs which only need 3 stones.
Thus the recycling of the various brick blocks yields different brick counts than recycling rock based blocks.

**This version does not touch the vanilla recipes, but it is planned to adjust the brick recipes
to be consistent with the cobble variants.**
